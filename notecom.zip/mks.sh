#!/bin/bash
rm notecom.zip
gcc -Wall -o build/notecom_l64 notecom.c -lm
i686-w64-mingw32-gcc -o build/notecom_w32.exe notecom.c
x86_64-w64-mingw32-gcc -o build/notecom_w64.exe notecom.c
zip notecom.zip -r build/
zip notecom.zip -r embedded/
zip notecom.zip -r license/
zip notecom.zip *.c
zip notecom.zip *.md
zip notecom.zip *.sh
