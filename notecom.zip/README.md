# README :  notecom
### description file for current C project
-----
  give in this file a precise description of your project and how it works !  
